const mysql = require("mysql");

// Create a connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root",  // Default user for XAMPP
    password: "",  // Default is empty
    database: "testing",  // Replace with your database name
});

// Connect to MySQL
db.connect(err => {
    if (err) {
        console.error("Database connection failed: " + err.stack);
        return;
    }
    console.log("Connected to MySQL database");

    // Query the database
    db.query("SELECT * FROM users", (err, result) => {
        if (err) {
            console.error("Error executing query:", err);
            return;
        }
        console.log("Data from users table:");
        console.table(result);  // Formats output in a nice table

        // Close the database connection after the query
        db.end(err => {
            if (err) {
                console.error("Error closing the database connection:", err);
            } else {
                console.log("Database connection closed.");
            }
        });
    });
});
