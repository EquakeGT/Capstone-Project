const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// MySQL Database Connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "testing"
});

db.connect(err => {
    if (err) {
        console.error("Database connection failed:", err);
        return;
    }
    console.log("Connected to MySQL database");
});

// Fetch All Users
app.get("/users", (req, res) => {
    db.query("SELECT UserID, Username, Email, Date_of_Birth, Role, Created_at, Last_login FROM users", (err, result) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(result);
        }
    });
});

// Fetch Total Users Count
app.get("/users/count", (req, res) => {
    db.query("SELECT COUNT(*) AS total FROM users", (err, result) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(result[0]);
        }
    });
});

// Add a New User
app.post("/users", (req, res) => {
    const { Username, Email, Password, Date_of_Birth, Role } = req.body;
    const query = "INSERT INTO users (Username, Email, Password, Date_of_Birth, Role) VALUES (?, ?, ?, ?, ?)";
    
    db.query(query, [Username, Email, Password, Date_of_Birth, Role], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "User added successfully!" });
    });
});

// Delete a User
app.delete("/users/:id", (req, res) => {
    const { id } = req.params;
    db.query("DELETE FROM users WHERE UserID = ?", [id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "User deleted successfully!" });
    });
});

// Fetch All Tasks
app.get("/tasks", (req, res) => {
    db.query("SELECT * FROM task", (err, result) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(result);
        }
    });
});



// Start Server
app.listen(5000, () => {
    console.log("Server running on port 5000");
});
