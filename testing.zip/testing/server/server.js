const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// MySQL Database Connection using Promises
const db = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "",
    database: "testing",
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
}).promise();

// Check Database Connection
db.getConnection()
    .then(() => console.log("Connected to MySQL database"))
    .catch(err => console.error("Database connection failed:", err));

// Fetch All Users
app.get("/users", async (req, res) => {
    try {
        const [result] = await db.query("SELECT UserID, Username, Email, Date_of_Birth, Role, Created_at, Last_login FROM users");
        res.json(result);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get("/reports", async (req, res) => {
    try {
      const [rows] = await db.query("SELECT ReportID, title, description, created_by, created_at, read_by_admin, severity FROM maintenanceReport");
      console.log(rows); // Check if severity is in the response
      res.json(rows);
    } catch (error) {
      console.error("Error fetching reports:", error); // Log any error
      res.status(500).json({ error: "Failed to fetch reports" });
    }
  });
  
  

app.put("/reports/:id/mark-read", async (req, res) => {
    const { id } = req.params;
    const { read_by_admin } = req.body;
  
    try {
      await db.query(
        "UPDATE MaintenanceReport SET read_by_admin = ? WHERE ReportID = ?",
        [read_by_admin, id]
      );
      res.json({ message: "Read status updated." });
    } catch (error) {
      console.error("Error updating read status:", error);
      res.status(500).json({ error: "Failed to update read status." });
    }
  });
  
  

app.get("/technician-reports", async (req, res) => { 
    try {
      const query = `
        SELECT tr.ReportID, u.Username AS TechnicianName, tr.TaskID,  
               tr.Location, tr.MachineType, tr.IssueEncountered, tr.ActionsTaken, 
               tr.TimeTaken, tr.FinalMachineStatus, tr.TaskCompleted, 
               tr.AdditionalNotes, tr.ReportedAt
        FROM TechnicianReport tr
        JOIN users u ON tr.TechnicianID = u.UserID;
      `;
      const [rows] = await db.query(query);
      console.log("Fetched Reports from DB:", rows); // Debugging
      res.json(rows);
    } catch (error) {
      console.error("Error fetching technician reports:", error);
      res.status(500).json({ error: "Failed to fetch technician reports" });
    }
  });
  
  



  


// Fetch Total Users Count
app.get("/users/count", async (req, res) => {
    try {
        const [result] = await db.query("SELECT COUNT(*) AS total FROM users");
        res.json(result[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Fetch All Technicians
app.get("/technicians", async (req, res) => {
    try {
        const [result] = await db.query("SELECT UserID, Username, Email FROM users WHERE Role = 'Technician'");
        res.json(result);
    } catch (err) {
        console.error("Error fetching technicians:", err);
        res.status(500).json({ error: "Error fetching technicians" });
    }
});

// Add a New User
app.post("/users", async (req, res) => {
    const { Username, Email, Password, Date_of_Birth, Role } = req.body;
    try {
        const query = "INSERT INTO users (Username, Email, Password, Date_of_Birth, Role) VALUES (?, ?, ?, ?, ?)";
        await db.query(query, [Username, Email, Password, Date_of_Birth, Role]);
        res.json({ message: "User added successfully!" });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Delete a User
app.delete("/users/:id", async (req, res) => {
    const { id } = req.params;
    try {
        await db.query("DELETE FROM users WHERE UserID = ?", [id]);
        res.json({ message: "User deleted successfully!" });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Fetch All Tasks
app.get("/tasks", async (req, res) => {
    try {
        const [result] = await db.query("SELECT * FROM task");
        res.json(result);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Assign or Update a Task
app.put("/tasks/:id", async (req, res) => {
    const { id } = req.params;
    let { assigned_to, assigned_by, status, assigned_at } = req.body;

    // Ensure `assigned_at` has a value (fallback to current timestamp)
    if (!assigned_at) assigned_at = new Date().toISOString();

    try {
        // Validate `assigned_to` and `assigned_by` exist in `users`
        if (assigned_to) {
            const [userCheck] = await db.query("SELECT UserID FROM users WHERE UserID = ?", [assigned_to]);
            if (userCheck.length === 0) {
                return res.status(400).json({ error: "Assigned technician does not exist" });
            }
        }

        if (assigned_by) {
            const [adminCheck] = await db.query("SELECT UserID FROM users WHERE UserID = ?", [assigned_by]);
            if (adminCheck.length === 0) {
                return res.status(400).json({ error: "Admin user does not exist" });
            }
        }

        // Update Task
        const query = "UPDATE task SET assigned_to=?, assigned_by=?, assigned_at=? WHERE TaskID=?";
        await db.query(query, [assigned_to || null, assigned_by || null, assigned_at, id]);
        
        // Update Task Status
        if (status) {
            await db.query("UPDATE task SET status=? WHERE TaskID=?", [status, id]);
        }

        res.json({ message: "Task updated successfully!" });
    } catch (err) {
        console.error("Error updating task:", err);
        res.status(500).json({ error: "Error updating task" });
    }
});

// Start Server
app.listen(5000, () => {
    console.log("Server running on port 5000");
});

app.get('/admin/system-overview', async (req, res) => {
    try {
      const [pendingTasks] = await db.query("SELECT COUNT(*) as total FROM Task WHERE status = 'Pending'");
      const [completedTasks] = await db.query("SELECT COUNT(*) as total FROM Task WHERE status = 'Completed'");
      const [unreadReports] = await db.query("SELECT COUNT(*) as total FROM MaintenanceReport WHERE read_by_admin = 0");
      const [needsMaintenance] = await db.query("SELECT COUNT(*) as total FROM TechnicianReport WHERE FinalMachineStatus = 'Needs Further Maintenance'");
  
      res.json({
        pendingTasks: pendingTasks[0].total,
        completedTasks: completedTasks[0].total,
        unreadReports: unreadReports[0].total,
        needsMaintenance: needsMaintenance[0].total
      });
    } catch (error) {
      console.error("System overview error:", error);
      res.status(500).json({ error: "Failed to load system overview" });
    }
  });

  
  app.get('/admin/system-overview', async (req, res) => {
    try {
      const [pendingTasks] = await db.query("SELECT COUNT(*) as total FROM Task WHERE status = 'Pending'");
      const [completedTasks] = await db.query("SELECT COUNT(*) as total FROM Task WHERE status = 'Completed'");
      const [unreadReports] = await db.query("SELECT COUNT(*) as total FROM MaintenanceReport WHERE read_by_admin = 0");
      const [needsMaintenance] = await db.query("SELECT COUNT(*) as total FROM TechnicianReport WHERE FinalMachineStatus = 'Needs Further Maintenance'");
  
      res.json({
        pendingTasks: pendingTasks[0].total,
        completedTasks: completedTasks[0].total,
        unreadReports: unreadReports[0].total,
        needsMaintenance: needsMaintenance[0].total
      });
    } catch (error) {
      console.error("System overview error:", error);
      res.status(500).json({ error: "Failed to load system overview" });
    }
  });

  
  