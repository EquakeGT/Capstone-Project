import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AdminDashboard from "./components/AdminDashboard";
import TaskManagement from "./components/TaskManagement";
import PredictiveMaintenanceReport from "./components/PredictiveMaintenanceReport";
import TechnicianReport from "./components/TechnicianReport";


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
        <Route path="/task-management" element={<TaskManagement />} />
        <Route path="/predictive-maintenance-report" element={<PredictiveMaintenanceReport />} />
        <Route path="/technician-report" element={<TechnicianReport />} />
        <Route path="/" element={<AdminDashboard />} />
       
      </Routes>
    </Router>
  );
}

export default App;
