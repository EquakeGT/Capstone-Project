import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AdminDashboard from "./components/AdminDashboard";
import TaskManagement from "./components/TaskManagement";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/admin-dashboard" element={<AdminDashboard />} /> 
        <Route path="/task-management" element={<TaskManagement />} />
        <Route path="/" element={<AdminDashboard />} /> 
      </Routes>
    </Router>
  );
}

export default App;
