import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import "../dashboard_styles.css";

const TechnicianReport = () => {
  const [reports, setReports] = useState([]);

  useEffect(() => {
    fetchReports();
  }, []);

  // Fetch Reports from Database
  const fetchReports = async () => {
    try {
      const response = await axios.get("http://localhost:5000/technician-reports");
      console.log("Fetched Reports:", response.data); // Debugging
      setReports(response.data);
    } catch (error) {
      console.error("Error fetching technician reports:", error);
    }
  };

  return (
    <div className="dashboard">
      {/* Sidebar */}
      <div className="sidebar">
        <h2>Admin Panel</h2>
        <nav>
          <Link to="/admin-dashboard">User Management</Link>
          <Link to="/task-management">Task Management</Link>
          <Link to="/predictive-maintenance-report">Predictive Maintenance Report</Link>
          <Link to="/technician-report" className="active">Technician Report</Link>
          <Link to="#">Logout</Link>
        </nav>
      </div>

      {/* Main Content */}
      <div className="main-content">
        <header>
          <h1>Technician Reports</h1>
        </header>

        {/* Report Table */}
        <div className="table-container">
          <h2>Technician Reports</h2>
          <table>
            <thead>
              <tr>
                <th>Report ID</th>
                <th>Technician</th>
                <th>Task ID</th>
                <th>Location</th>
                <th>Machine Type</th>
                <th>Issue Encountered</th>
                <th>Actions Taken</th>
                <th>Time Taken (mins)</th>
                <th>Final Machine Status</th>
                <th>Task Completed</th>
                <th>Additional Notes</th>
                <th>Submitted At</th>
              </tr>
            </thead>
            <tbody>
              {reports.length > 0 ? (
                reports.map((report) => (
                  <tr key={report.ReportID}>
                    <td>{report.ReportID}</td>
                    <td>{report.TechnicianName}</td> {/* Changed to TechnicianName */}
                    <td>{report.TaskID}</td>
                    <td>{report.Location}</td>
                    <td>{report.MachineType}</td>
                    <td>{report.IssueEncountered || "No issues reported"}</td>
                    <td>{report.ActionsTaken || "No actions taken"}</td>
                    <td>{report.TimeTaken ? `${report.TimeTaken} mins` : "N/A"}</td>
                    <td>{report.FinalMachineStatus || "Unknown"}</td>
                    <td>{report.TaskCompleted === "Yes" ? "✅ Yes" : "❌ No"}</td>
                    <td>{report.AdditionalNotes || "N/A"}</td>
                    <td>{report.ReportedAt ? new Date(report.ReportedAt).toLocaleString() : "N/A"}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="12">No reports found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TechnicianReport;
