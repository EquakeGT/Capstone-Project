import React, { useEffect, useState } from "react";
import axios from "axios";
import "../dashboard_styles.css";
import { Link } from "react-router-dom";

const AdminDashboard = () => {
  const [users, setUsers] = useState([]);
  const [totalUsers, setTotalUsers] = useState(0);
  const [totalAdmins, setTotalAdmins] = useState(0);
  const [totalTechnicians, setTotalTechnicians] = useState(0);
  const [totalDataScientists, setTotalDataScientists] = useState(0);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRole, setSelectedRole] = useState("");

  const [newUser, setNewUser] = useState({
    Username: "",
    Email: "",
    Password: "",
    Date_of_Birth: "",
    Role: "Admin",
  });

  useEffect(() => {
    fetchUsers();
  }, []);

  // Fetch users and update total counts
  const fetchUsers = async () => {
    try {
      const response = await axios.get("http://localhost:5000/users");
      setUsers(response.data);
      setTotalUsers(response.data.length);
      setTotalAdmins(response.data.filter(user => user.Role === "Admin").length);
      setTotalTechnicians(response.data.filter(user => user.Role === "Technician").length);
      setTotalDataScientists(response.data.filter(user => user.Role === "Data Scientist").length);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  // Handle input change
  const handleChange = (e) => {
    setNewUser({ ...newUser, [e.target.name]: e.target.value });
  };

  // Add user with validation
  const handleAddUser = async (e) => {
    e.preventDefault();
    if (users.some((user) => user.Email === newUser.Email)) {
      window.alert("Error: A user with this email already exists!");
      return;
    }
    try {
      await axios.post("http://localhost:5000/users", newUser);
      fetchUsers();
      setIsModalOpen(false);
      setNewUser({ Username: "", Email: "", Password: "", Date_of_Birth: "", Role: "Admin" });
      window.alert("User successfully added!");
    } catch (error) {
      console.error("Error adding user:", error);
      window.alert("Error adding user. Please try again.");
    }
  };

  // Delete user with confirmation
  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this user?")) return;
    try {
      await axios.delete(`http://localhost:5000/users/${id}`);
      fetchUsers();
      window.alert("User deleted successfully!");
    } catch (error) {
      console.error("Error deleting user:", error);
    }
  };

  // Filter users based on search and role
  const filteredUsers = users.filter((user) =>
    user.Username.toLowerCase().includes(searchQuery.toLowerCase()) &&
    (selectedRole ? user.Role === selectedRole : true)
  );

  return (
    <div className="dashboard">
      {/* Sidebar */}
      <div className="sidebar">
        <h2>Admin Panel</h2>
        <nav>
          <Link to="/admin-dashboard" className="active">User Management</Link>
          <Link to="/task-management">Task Management</Link>
          <Link to="#">Predictive Maintenance Report</Link>
          <Link to="#">Technician Progress Report</Link>
          <Link to="#">Logout</Link>
          <Link to="#">Logout</Link>
        </nav>
      </div>

      {/* Main Content */}
      <div className="main-content">
        <header>
          <h1>Welcome, Admin</h1>
        </header>

        {/* Dashboard Cards */}
        <div className="cards">
          <div className="card"><h3>Total Users</h3><p>{totalUsers || "Loading..."}</p></div>
          <div className="card"><h3>Total Admins</h3><p>{totalAdmins || "Loading..."}</p></div>
          <div className="card"><h3>Total Technicians</h3><p>{totalTechnicians || "Loading..."}</p></div>
          <div className="card"><h3>Total Data Scientists</h3><p>{totalDataScientists || "Loading..."}</p></div>
        </div>

        {/* Search & Filter */}
        <div className="search-filter-container">
          <input
            type="text"
            placeholder="Search by username..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
          />
          <select value={selectedRole} onChange={(e) => setSelectedRole(e.target.value)} className="filter-dropdown">
            <option value="">All Roles</option>
            <option value="Admin">Admin</option>
            <option value="Data Scientist">Data Scientist</option>
            <option value="Technician">Technician</option>
          </select>
          <button className="add-user-btn" onClick={() => setIsModalOpen(true)}>+ Add User</button>
        </div>

        {/* User Table */}
        <div className="table-container">
          <h2>User List</h2>
          <table>
            <thead>
              <tr>
                <th>UserID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Date of Birth</th>
                <th>Role</th>
                <th>Created At</th>
                <th>Last Login</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map(user => (
                <tr key={user.UserID}>
                  <td>{user.UserID}</td>
                  <td>{user.Username}</td>
                  <td>{user.Email}</td>
                  <td>{user.Date_of_Birth}</td>
                  <td>{user.Role}</td>
                  <td>{user.Created_at}</td>
                  <td>{user.Last_login}</td>
                  <td>
                    <button onClick={() => handleDelete(user.UserID)} className="delete-btn">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Add User Modal */}
        {isModalOpen && (
          <div className="modal-overlay">
            <div className="modal">
              <h2>Add New User</h2>
              <form onSubmit={handleAddUser}>
                <input type="text" name="Username" placeholder="Username" value={newUser.Username} onChange={handleChange} required />
                <input type="email" name="Email" placeholder="Email" value={newUser.Email} onChange={handleChange} required />
                <input type="password" name="Password" placeholder="Password" value={newUser.Password} onChange={handleChange} required />
                <input type="date" name="Date_of_Birth" value={newUser.Date_of_Birth} onChange={handleChange} required />
                <select name="Role" value={newUser.Role} onChange={handleChange}>
                  <option value="Admin">Admin</option>
                  <option value="Data Scientist">Data Scientist</option>
                  <option value="Technician">Technician</option>
                </select>
                <div className="modal-buttons">
                  <button type="submit">Add User</button>
                  <button type="button" onClick={() => setIsModalOpen(false)}>Cancel</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
