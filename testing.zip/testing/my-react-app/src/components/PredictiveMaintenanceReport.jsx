import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import "../dashboard_styles.css";

const PredictiveMaintenanceReport = () => {
  const [reports, setReports] = useState([]);

  useEffect(() => {
    fetchReports();
  }, []);

  const fetchReports = async () => {
    try {
      const response = await axios.get("http://localhost:5000/reports");
      setReports(response.data);
    } catch (error) {
      console.error("Error fetching reports:", error);
    }
  };

  const handleCheckboxChange = async (reportId, newStatus) => {
    try {
      await axios.put(`http://localhost:5000/reports/${reportId}/mark-read`, {
        read_by_admin: newStatus,
      });
      fetchReports();
    } catch (error) {
      console.error("Error updating read status:", error);
    }
  };

  const totalReports = reports.length;
  const readReports = reports.filter((r) => r.read_by_admin).length;
  const unreadReports = totalReports - readReports;
  const latestReport = reports.length > 0 ? reports[0] : null;

  return (
    <div className="dashboard">
      {/* Sidebar */}
      <div className="sidebar">
        <h2>Admin Panel</h2>
        <nav>
        <Link to="/admin-dashboard" >User Management</Link>
        <Link to="/task-management">Task Management</Link>
        <Link to="/predictive-maintenance-report" className="active">Predictive Maintenance Report</Link>
        <Link to="/technician-report">Technician Report</Link>
        <Link to="#">Logout</Link>
        
        </nav>
      </div>

      {/* Main Content */}
      <div className="main-content">
        <header>
          <h1>Predictive Maintenance Reports</h1>
        </header>

        <div className="report-page" style={{ display: "flex", gap: "30px" }}>
          {/* Table Section */}
          <div className="main-report-content" style={{ flex: 2 }}>
            <div className="table-container">
              <h2>Maintenance Reports</h2>
              <table>
                <thead>
                  <tr>
                    <th>Report ID</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Created By</th>
                    <th>Created At</th>
                    <th>Severity</th>
                    <th>Read</th>
                  </tr>
                </thead>
                <tbody>
                  {reports.length > 0 ? (
                    reports.map((report) => (
                      <tr
                        key={report.ReportID}
                        className={report.read_by_admin ? "read-row" : ""}
                      >
                        <td>{report.ReportID}</td>
                        <td>{report.title}</td>
                        <td>{report.description}</td>
                        <td>{report.created_by}</td>
                        <td>{new Date(report.created_at).toLocaleString()}</td>
                        <td>{report.severity}</td>
                        <td>
                          <input
                            type="checkbox"
                            checked={report.read_by_admin}
                            onChange={() =>
                              handleCheckboxChange(
                                report.ReportID,
                                !report.read_by_admin
                              )
                            }
                          />
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="7">No reports found</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Summary Panel */}
          <div className="report-summary-panel" style={{
            flex: 1,
            background: "#fff",
            padding: "20px",
            borderRadius: "10px",
            boxShadow: "0 0 10px rgba(0,0,0,0.05)",
            height: "fit-content"
          }}>
            <h3>Report Overview</h3>
            <p><strong>Total Reports:</strong> {totalReports}</p>
            <p><strong>Read Reports:</strong> {readReports}</p>
            <p><strong>Unread Reports:</strong> {unreadReports}</p>
            <hr />
<h4 style={{ marginTop: "20px", color: "#333",fontSize:"25px" }}>High Severity Reports</h4>
{reports.filter(r => r.severity === "High").length > 0 ? (
  <ul style={{ paddingLeft: "18px", marginTop: "20px", color: "#333", fontSize: "18px" }}>
    {reports
      .filter(r => r.severity === "High")
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, 5)
      .map((r) => (
        <li key={r.ReportID} style={{ marginBottom: "8px" }}>
          <strong>{r.title}</strong><br />
          <small>{new Date(r.created_at).toLocaleDateString()}</small>
        </li>
      ))}
  </ul>
) : (
  <p style={{ fontStyle: "italic", color: "#666" }}>No high severity reports.</p>
)}


          </div>
        </div>
      </div>
    </div>
  );
};

export default PredictiveMaintenanceReport;
