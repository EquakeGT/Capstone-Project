import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import "../dashboard_styles.css";

const TaskManagement = () => {
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/tasks")
      .then(response => {
        setTasks(response.data);
      })
      .catch(error => {
        console.error("Error fetching tasks:", error);
      });
  }, []);

  return (
    <div className="dashboard">
      {/* Sidebar */}
      <div className="sidebar">
        <h2>Admin Panel</h2>
        <nav>
          <Link to="/admin-dashboard">User Management</Link>
          <Link to="/task-management" className="active">Task Management</Link>
          <Link to="#">Technician Report</Link>
          <Link to="#">Logout</Link>
        </nav>
      </div>

      {/* Main Content */}
      <div className="main-content">
        <header>
          <h1>Task Management</h1>
        </header>

        {/* Task Table */}
        <div className="table-container">
          <h2>Task List</h2>
          <table>
            <thead>
              <tr>
                <th>Task ID</th>
                <th>Task Name</th>
                <th>Assigned To</th>
                <th>Status</th>
                <th>Assigned At</th>
                <th>Due Date</th>
                <th>Completed At</th>
                <th>Assigned By</th>
              </tr>
            </thead>
            <tbody>
              {tasks.length > 0 ? (
                tasks.map(task => (
                  <tr key={task.TaskID}>
                    <td>{task.TaskID}</td>
                    <td>{task.task_name}</td>
                    <td>{task.assigned_to}</td>
                    <td>{task.status}</td>
                    <td>{task.assigned_at}</td>
                    <td>{task.due_date}</td>
                    <td>{task.completed_at || "N/A"}</td>
                    <td>{task.assigned_by}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="8">No tasks found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TaskManagement;
