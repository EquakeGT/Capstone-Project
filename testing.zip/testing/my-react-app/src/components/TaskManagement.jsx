import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import "../dashboard_styles.css";

const TaskManagement = () => {
  const [tasks, setTasks] = useState([]);
  const [technicians, setTechnicians] = useState([]);
  const [selectedTask, setSelectedTask] = useState(null);
  const [selectedTechnician, setSelectedTechnician] = useState("");
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);

  useEffect(() => {
    fetchTasks();
    fetchTechnicians();
  }, []);

  // Fetch All Tasks
  const fetchTasks = async () => {
    try {
      const response = await axios.get("http://localhost:5000/tasks");
      setTasks(response.data);
    } catch (error) {
      console.error("Error fetching tasks:", error);
    }
  };

  // Fetch All Technicians
  const fetchTechnicians = async () => {
    try {
      const response = await axios.get("http://localhost:5000/users");
      const filteredTechnicians = response.data.filter(user => user.Role === "Technician");
      setTechnicians(filteredTechnicians);
    } catch (error) {
      console.error("Error fetching technicians:", error);
    }
  };

  // Open Assign Modal
  const handleAssignClick = (task) => {
    setSelectedTask(task);
    setIsAssignModalOpen(true);
  };

  // Assign Task
  const handleAssignTask = async () => {
    if (!selectedTechnician) {
      alert("Please select a technician.");
      return;
    }

    const requestData = {
      assigned_to: Number(selectedTechnician), // ✅ Ensure it's a number
      assigned_by: 64, // TODO: Replace with logged-in admin's UserID
      status: "Assigned",
      assigned_at: new Date().toISOString(),
    };

    console.log("Sending Data:", requestData); // Debugging line

    try {
      await axios.put(`http://localhost:5000/tasks/${selectedTask.TaskID}`, requestData);

      setIsAssignModalOpen(false);
      setSelectedTask(null);
      setSelectedTechnician("");
      fetchTasks(); // Refresh task list
      alert("Task assigned successfully!");
    } catch (error) {
      console.error("Error assigning task:", error.response?.data || error.message);
    }
  };

  // Format Date
  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    const date = new Date(dateString);
    return date.toLocaleString(); // Formats as readable date
  };

  return (
    <div className="dashboard">
      {/* Sidebar */}
      <div className="sidebar">
        <h2>Admin Panel</h2>
        <nav>
          <Link to="/admin-dashboard">User Management</Link>
          <Link to="/task-management" className="active">Task Management</Link>
          <Link to="/predictive-maintenance-report">Predictive Maintenance Report</Link>
          <Link to="/technician-report">Technician Report</Link>
         <Link to="#">Logout</Link>
        </nav>
      </div>

      {/* Main Content */}
      <div className="main-content">
        <header>
          <h1>Task Management</h1>
        </header>

        {/* Task Table */}
        <div className="table-container">
          <h2>Task List</h2>
          <table>
            <thead>
              <tr>
                <th>Task ID</th>
                <th>Task Name</th>
                <th>Assigned To</th>
                <th>Status</th>
                <th>Assigned At</th>
                <th>Due Date</th>
                <th>Completed At</th>
                <th>Assigned By</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {tasks.length > 0 ? (
                tasks.map((task) => (
                  <tr key={task.TaskID}>
                    <td>{task.TaskID}</td>
                    <td>{task.task_name}</td>
                    <td>
                      {task.assigned_to
                        ? technicians.find((tech) => tech.UserID === task.assigned_to)?.Username || "Unknown"
                        : "Unassigned"}
                    </td>
                    <td>{task.status}</td>
                    <td>{formatDate(task.assigned_at)}</td>
                    <td>{formatDate(task.due_date)}</td>
                    <td>{formatDate(task.completed_at)}</td>
                    <td>
                      {task.assigned_by
                        ? technicians.find((tech) => tech.UserID === task.assigned_by)?.Username || "Admin"
                        : "N/A"}
                    </td>
                    <td>
                      {(task.status === "Pending" || task.status === "Assigned") && (
                        <button onClick={() => handleAssignClick(task)} className="assign-btn">
                          {task.status === "Pending" ? "Assign" : "Reassign"}
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="9">No tasks found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assign Task Modal */}
      {isAssignModalOpen && (
        <div className="modal-overlay">
          <div className="modal">
            <h2>Assign Task</h2>
            <p>Task: {selectedTask?.task_name}</p>
            <select
              value={selectedTechnician}
              onChange={(e) => setSelectedTechnician(e.target.value)}
            >
              <option value="">Select Technician</option>
              {technicians.map((tech) => (
                <option key={tech.UserID} value={tech.UserID}>
                  {tech.Username}
                </option>
              ))}
            </select>
            <div className="modal-buttons">
              <button onClick={handleAssignTask}>Assign</button>
              <button onClick={() => setIsAssignModalOpen(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TaskManagement;
