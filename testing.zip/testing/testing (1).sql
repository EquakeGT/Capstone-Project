-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2025 at 02:06 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `testing`
--

-- --------------------------------------------------------

--
-- Table structure for table `maintenancereport`
--

CREATE TABLE `maintenancereport` (
  `ReportID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `read_by_admin` tinyint(1) DEFAULT 0,
  `severity` enum('Low','Medium','High') DEFAULT 'Medium'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `maintenancereport`
--

INSERT INTO `maintenancereport` (`ReportID`, `title`, `description`, `created_by`, `created_at`, `read_by_admin`, `severity`) VALUES
(2, 'Thermal Imaging Results', 'Infrared analysis indicates overheating in pump Y.', 39, '2025-03-29 04:32:06', 1, 'Medium'),
(4, 'Motor Efficiency Analysis', 'Motor Z is operating at 85% efficiency.', 39, '2025-03-29 04:32:06', 1, 'Medium'),
(16, 'Broken Conveyor Belt', 'The conveyor belt stopped working during the night shift. It needs immediate replacement.', 39, '2025-04-02 01:30:00', 1, 'Low'),
(18, 'Oil Leak Detected', 'Oil leakage detected on the hydraulic system. Needs to be repaired to avoid further damage.', 39, '2025-04-03 02:15:00', 0, 'Medium'),
(20, 'Gearbox Failure', 'The gearbox failed during operation. It is a critical issue that needs immediate attention to avoid downtime.', 39, '2025-04-04 00:45:00', 1, 'Medium'),
(22, 'Dust Accumulation in Filters', 'Dust is accumulating in the air filters, reducing efficiency. It needs cleaning soon.', 39, '2025-04-05 08:30:00', 0, 'Low'),
(44, 'Bearing Failure Detected', 'Vibration analysis indicates imminent bearing failure in motor M-204.', 39, '2025-04-15 03:33:09', 0, 'High'),
(45, 'Overheating Alert in Conveyor System', 'Thermal imaging reveals abnormal heat levels in conveyor drive units.', 39, '2025-04-15 03:33:09', 0, 'High'),
(46, 'Oil Leakage in Hydraulic Press', 'Oil detected pooling beneath hydraulic unit. Potential for pressure loss.', 39, '2025-04-15 03:33:09', 0, 'High'),
(47, 'Unexpected Downtime Risk', 'Predictive model flags unplanned downtime risk for CNC machine within 48 hours.', 39, '2025-04-15 03:33:09', 0, 'High'),
(48, 'Electrical Fluctuations Detected', 'Sensor data shows irregular voltage patterns in panel P-37.', 39, '2025-04-15 03:33:09', 0, 'High');

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `TaskID` int(11) NOT NULL,
  `task_name` varchar(255) NOT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `status` enum('Pending','In Progress','Completed') NOT NULL DEFAULT 'Pending',
  `assigned_at` datetime DEFAULT current_timestamp(),
  `due_date` date NOT NULL,
  `completed_at` datetime DEFAULT NULL,
  `assigned_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`TaskID`, `task_name`, `assigned_to`, `status`, `assigned_at`, `due_date`, `completed_at`, `assigned_by`) VALUES
(7, 'Replace Air Filters', 40, '', '2025-04-06 12:44:21', '2025-04-12', NULL, 64),
(9, 'Inspect Conveyor Belt Sensors', 40, '', '2025-04-13 07:13:38', '2025-04-18', NULL, 64),
(10, 'Check Hydraulic Fluid Levels', 40, '', '2025-04-13 07:17:44', '2025-04-20', NULL, 64),
(11, 'Run Diagnostic Software', 40, '', '2025-04-15 02:40:09', '2025-04-22', NULL, 64),
(12, 'Verify Motor Alignment', 40, '', '2025-04-15 03:21:18', '2025-04-25', NULL, 64);

-- --------------------------------------------------------

--
-- Table structure for table `technicianreport`
--

CREATE TABLE `technicianreport` (
  `ReportID` int(11) NOT NULL,
  `TaskID` int(11) NOT NULL,
  `TechnicianID` int(11) NOT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `MachineType` varchar(255) DEFAULT NULL,
  `IssueEncountered` text DEFAULT NULL,
  `ActionsTaken` text DEFAULT NULL,
  `TimeTaken` int(11) DEFAULT NULL,
  `FinalMachineStatus` enum('Fixed','Needs Further Maintenance','Unresolved') DEFAULT NULL,
  `TaskCompleted` enum('Yes','No') DEFAULT NULL,
  `AdditionalNotes` text DEFAULT NULL,
  `ReportedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `technicianreport`
--

INSERT INTO `technicianreport` (`ReportID`, `TaskID`, `TechnicianID`, `Location`, `MachineType`, `IssueEncountered`, `ActionsTaken`, `TimeTaken`, `FinalMachineStatus`, `TaskCompleted`, `AdditionalNotes`, `ReportedAt`) VALUES
(5, 7, 40, 'Warehouse D', 'Air Filter System', 'Reduced airflow due to clogged filter', 'Replaced air filter', 20, 'Fixed', 'Yes', 'Check filter replacement schedule', '2025-03-29 05:13:12'),
(7, 9, 40, 'Sorting Unit', 'Conveyor Belt', 'Belt misalignment detected', 'Realigned belt and tested operation', 40, 'Fixed', 'Yes', 'Inspect belt alignment weekly', '2025-03-29 05:13:12'),
(9, 11, 40, 'Software Control Room', 'Diagnostic System', 'System crash during diagnostics', 'Restarted system and updated software', 25, 'Fixed', 'Yes', 'Consider software upgrade', '2025-03-29 05:13:12');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Date_of_Birth` date DEFAULT NULL,
  `Role` varchar(50) DEFAULT NULL,
  `Updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Last_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `Username`, `Email`, `Password`, `Date_of_Birth`, `Role`, `Updated_at`, `Created_at`, `Last_login`) VALUES
(39, 'datasci3', 'datasci3@example.com', '', '1995-04-18', 'Data Scientist', '2025-03-22 05:34:37', '2025-03-22 04:30:00', '2025-03-22 14:30:00'),
(40, 'tech3', 'tech3@example.com', '', '2000-08-30', 'Technician', '2025-03-22 05:34:37', '2025-03-22 04:40:00', '2025-03-22 14:40:00'),
(63, 'tech2', 'techc@mail.com', 'adsad', '2024-11-26', 'Technician', '2025-03-24 07:46:22', '2025-03-24 07:46:22', NULL),
(64, 'admin1', 'admin@laa', 'dasdsad', '2025-02-27', 'Admin', '2025-03-24 07:58:48', '2025-03-24 07:58:48', NULL),
(65, 'jajke', 'adasda@hgfhfg', 'asdasd', '2025-03-14', 'Data Scientist', '2025-03-25 03:26:47', '2025-03-25 03:26:47', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `maintenancereport`
--
ALTER TABLE `maintenancereport`
  ADD PRIMARY KEY (`ReportID`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`TaskID`),
  ADD KEY `assigned_to` (`assigned_to`),
  ADD KEY `assigned_by` (`assigned_by`);

--
-- Indexes for table `technicianreport`
--
ALTER TABLE `technicianreport`
  ADD PRIMARY KEY (`ReportID`),
  ADD KEY `TaskID` (`TaskID`),
  ADD KEY `TechnicianID` (`TechnicianID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `maintenancereport`
--
ALTER TABLE `maintenancereport`
  MODIFY `ReportID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `TaskID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `technicianreport`
--
ALTER TABLE `technicianreport`
  MODIFY `ReportID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `maintenancereport`
--
ALTER TABLE `maintenancereport`
  ADD CONSTRAINT `maintenancereport_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`UserID`) ON DELETE CASCADE;

--
-- Constraints for table `task`
--
ALTER TABLE `task`
  ADD CONSTRAINT `task_ibfk_1` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`UserID`) ON DELETE CASCADE,
  ADD CONSTRAINT `task_ibfk_2` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`UserID`) ON DELETE CASCADE;

--
-- Constraints for table `technicianreport`
--
ALTER TABLE `technicianreport`
  ADD CONSTRAINT `technicianreport_ibfk_1` FOREIGN KEY (`TaskID`) REFERENCES `task` (`TaskID`) ON DELETE CASCADE,
  ADD CONSTRAINT `technicianreport_ibfk_2` FOREIGN KEY (`TechnicianID`) REFERENCES `users` (`UserID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
